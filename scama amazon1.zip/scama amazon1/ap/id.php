<?php
$user_ids=array("1422115546");
$sms='1';
$error='0';
$billing='1'
?>
